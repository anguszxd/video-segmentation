function M = replaceDiagonal(M,vals)

M(linspace(1,numel(M),length(M))) = vals;