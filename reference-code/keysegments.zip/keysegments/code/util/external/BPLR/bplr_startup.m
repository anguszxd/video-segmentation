addpath([pwd '/detector'])
addpath([pwd '/detector/util'])
addpath([pwd '/descriptor'])
addpath([pwd '/display'])

addpath([pwd '/external/matlab_bgl/'])
addpath([pwd '/external/pwmetric/'])
addpath([pwd '/external/vlfeat-0.9.8/toolbox'])
addpath([pwd '/external/bsr/lib'])
addpath([pwd '/external/spanning_tree'])
vl_setup
disp('BPLR ready.')