function V = vec(V)

V = V(:);